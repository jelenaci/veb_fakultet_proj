$(function(){
    $('#forma').on('submit', function (e) {
        e.preventDefault();
        let errorMessage = $('#error-message'); 
        errorMessage.hide(); 

        let form = new FormData();
        form.append("email", $('#email').val());
        form.append("password", $('#lozinka').val());
        form.append("apitoken", $('meta[name="apitoken"]').attr('content'));

        let settings = {
            "url": "https://vsis.mef.edu.rs/projekat/ulaznice/public_html/api/login",
            "method": "POST",
            "timeout": 0,
            "headers": {
                "Accept": "application/json"
            },
            "processData": false,
            "mimeType": "multipart/form-data",
            "contentType": false,
            "data": form,
            "dataType": "json",
            "success": function(response){
                if(response.error !== undefined){
                    errorMessage.html(response.responseJSON.error);
                    errorMessage.show(); // Show the error message
                    $('#lozinka').val('');
                }
                else {
                    localStorage.setItem('apitoken', response.apitoken);
                    localStorage.setItem('type', response.type);
                    if(localStorage.getItem("type") === 'администратор'){
                        window.location = 'administrator.html'; 
                    }
                    else if(localStorage.getItem("type") === 'благајник'){
                        window.location = 'blagajnik.html'; 
                    }
                    else if(localStorage.getItem("type") === 'регистровани корисник'){
                        window.location = 'korisnik.html'; 
                    }
                }
            },
            'error': function(response){
                errorMessage.html(response.responseJSON.error);
                errorMessage.show(); 
                $('#lozinka').val('');
            }
        };
        $.ajax(settings);
    })
});


